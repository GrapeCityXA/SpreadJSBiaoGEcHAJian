<template>
    <div>
        Hello SpreadJS
    </div>
</template>

<script lang="js">


export default defineComponent({
 
})
</script>
<style>
 
</style>