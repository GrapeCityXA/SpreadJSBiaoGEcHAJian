
export default function OnlineSpread(){
    return(
        <div style={{height: '98vh'}}>
          Hello SpreadJS
        </div>
    )
}