import { useState } from 'react'
import OnlineSpread from './components/OnlineSpread'


function App() {
  return (
    <div className="App">
       <OnlineSpread/>
    </div>
  )
}

export default App
