//（第一步：引入资源）
// 引入SpreadJS核心资源
import GC from '@grapecity/spread-sheets'
// 引入中文资源，也可以使用日文或韩文，按照自己的需求安装不同语言资源并引入即可
import '@grapecity/spread-sheets-resources-zh'
//引入支持react的工作簿、工作表组件
import {SpreadSheets,Worksheet,} from '@grapecity/spread-sheets-react'
//引入css
import "@grapecity/spread-sheets/styles/gc.spread.sheets.excel2013lightGray.css"
GC.Spread.Common.CultureManager.culture('zh-cn')
export default function OnlineSpread(){
    let workbook:GC.Spread.Sheets.Workbook|null = null
    const initWorkbook = (spreadEntity:GC.Spread.Sheets.Workbook) => {
        let workbook = spreadEntity
        //1.设置表单数量
        workbook.setSheetCount(5) 
        //2.获取操作的工作表
        let sheet:GC.Spread.Sheets.Worksheet = workbook.getSheetFromName('Sheet2')
        //3.设置日期
        sheet.setValue(0,0,new Date())
        //设置单元日期格格式的方法(setFormatter)
        sheet.setFormatter(0,0,'YYYY-MM-DD',GC.Spread.Sheets.SheetArea.viewport)
        console.log(sheet.getValue(0,0),sheet.getText(0,0))
        //设置列宽
        sheet.setColumnWidth(0,150)
        //设置公式
        sheet.setFormula(0,1,'=sum(C1:C5)')
        //切换活动sheet
        workbook.setActiveSheet('Sheet2')
    }  

    return( 
        <div style={{height: '98vh'}}>
          <SpreadSheets workbookInitialized={initWorkbook}></SpreadSheets>
        </div>
    )
}