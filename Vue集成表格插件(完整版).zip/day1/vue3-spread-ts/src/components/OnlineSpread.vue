<script>
//1.引入资源2.设置宽高格式和中英文3.设置内容格式（设置日期、公式、表单数量等）4.上传文件5.下载文件6.打印文件7.导出pdf
//第一步：引入vue组件
import {defineComponent} from 'vue'
// spreadjs组件运行时资源
import * as GC from "@grapecity/spread-sheets"
//引入Vue支持组件
import {GcSpreadSheets,GcWorksheet} from "@grapecity/spread-sheets-vue"
//引入符合自己项目主题的样式
import "@grapecity/spread-sheets/styles/gc.spread.sheets.excel2013white.css"
//设置中文
import "@grapecity/spread-sheets-resources-zh"
// 引入导入导出文件相关的资源
import * as ExcelIO from "@grapecity/spread-excelio"
//引入文件导出
import {saveAs} from 'file-saver'
//引入打印相关资源
import "@grapecity/spread-sheets-print"
//引入导出pdf资源
import "@grapecity/spread-sheets-pdf"
 
//引入语言资源（支持中英文）
GC.Spread.Common.CultureManager.culture('zh-cn')

export default defineComponent({
    //第二步：引入组件
    components:{
        'gc-spread-sheets':GcSpreadSheets
        
    },
    spread.options.showVerticalScrollbar = false;
    setup(){
        //设置高度格式
        const hostStyle={
            height:'90vh'
        }
        //
        let spread = null
        const initWorkbook = (spreadEntity) =>{
            spread = spreadEntity
            let sheet = spread.getActiveSheet()
            sheet.setValue(0,0,'grapeCity')
        }
        //文件上传的方法
        const importFile = (file) => {
            let io = new ExcelIO.IO()
            // excelio打开文件，回调函数中的参数时spreadjs支持的json格式
            io.open(file,(fileJSON) => {
                // fromJSON中第二个参数为导入文件的控制参数，默认均为false,根据自己的需求添加,都不要修改时可不传
                spread.fromJSON(fileJSON,{
                    ignoreFormula: false,    //导入忽略公式    
                    ignoreStyle: false,      //导入忽略样式
                    frozenColumnsAsRowHeaders: false,   //将冻结列当作行头
                    frozenRowsAsColumnHeaders: false,   //将冻结行作为列头
                    // 导入文件不立即计算. Excel文件保存时会自动计算,当文件比较大时,可以导入后不计算,提高导入效率.
                    doNotRecalculateAfterLoad: false    
                })
            })
            return false
        }

        //文件下载的方法
        const downloadFile = () => {
        //获取当前工作簿json,toJSON也可以根据需求设置参数,参考学习指南导入导出json
            let fileJson = spread.toJSON()
            //创建文件IO实例
            let io = new ExcelIO.IO()
            //保存文件
            io.save(fileJson,(blob)=>{
                // excelIO将文件转化为blob,传递给回调函数,然后执行file-saver的saveAs保存excel文件.
                saveAs(blob,'导出文件.xlsx')
            },(e) => {
                console.log(e)
            })
        }


    //打印文件
    const printFile = () => {
            let printInfo = new GC.Spread.Sheets.Print.PrintInfo()
            printInfo.fitPagesWide(1)    //将打印宽度调整到一页
            printInfo.showColumnHeader(false)    //打印不显示列头
            printInfo.showRowHeader(false)          //打印不显示行头
            let sheet = spread.getActiveSheet()
            //打印信息是设置在单个sheet上的，如果要整个spread工作簿有效，需要循环设置，每个工作表也可以设置不同的打印参数。
            sheet.printInfo(printInfo)             
            spread.print()
        }

       //导出PDF
        const exportPDF = () => {
            let printInfo = new GC.Spread.Sheets.Print.PrintInfo()
            printInfo.fitPagesWide(1)    //将打印宽度调整到一页
            printInfo.showColumnHeader(false)    //打印不显示列头
            printInfo.showRowHeader(false)          //打印不显示行头 
            let sheet = spread.getActiveSheet()
            sheet.printInfo(printInfo)
            spread.savePDF((blob)=>{
                saveAs(blob,'导出.PDF')
            },(e)=>{
                console.log(e)
            },{
                title: "Test Title",
                author: "Test Author",
                subject: "Test Subject",
                keywords: "Test Keywords",
                creator: "test Creator",
                }
            )
        }

        return{
            hostStyle,initWorkbook,importFile,downloadFile,printFile,exportPDF
        }
    },

})
</script>


<!--<template>-->
    <!--第二步，使用hostStyle标签设置格式-->
   <!-- <gc-spread-sheets :hostStyle="hostStyle" @workbookInitialized="initWorkbook"></gc-spread-sheets> -->
<!-- </template> -->

<!--文件上传组件-->
<template>
    <div>
        <el-upload
            class="upload-demo"
            accept=".xlsx"
            :before-upload="importFile"
            action=''
        >
            <el-button type="primary">上传文件</el-button>
        </el-upload>
        <el-button type="primary" @click="downloadFile">下载文件</el-button>
        <!-- <el-button type="primary" @click="printFile">打印</el-button>
        <el-button type="primary" @click="exportPDF">导出PDF</el-button> -->
        <!--第二步，使用hostStyle标签设置格式-->
         <gc-spread-sheets :hostStyle="hostStyle" @workbookInitialized="initWorkbook"></gc-spread-sheets>
    </div>
</template>

<style>

    .upload-demo{
        display: inline-block;
        margin-right:8px;
    }
 
</style>